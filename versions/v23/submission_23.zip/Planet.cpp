#include "Planet.hpp"

#include "Instance.hpp"

Planet::Planet(EntityId id) : Entity(id)
{
}